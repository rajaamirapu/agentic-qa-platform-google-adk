"""
RequirementAgent — Deck step 1: "Understand Requirements"

Extracts testable Given/When/Then scenarios from a parsed Story,
tagged as happy_path / edge_case / negative — mirroring the deck's
"generate ... covering happy path, edge cases, and negative scenarios".
"""
from __future__ import annotations

import json
import re

from config import SETTINGS, call_agent
from models import AcceptanceCriterion, Requirements, Story
from prompts.prompt_templates import (
    REQUIREMENT_EXTRACTION_PROMPT,
    REQUIREMENT_EXTRACTION_SYSTEM,
)


class RequirementAgent:
    def extract(self, story: Story) -> Requirements:
        if SETTINGS.mock_mode:
            return self._mock_extract(story)

        raw = call_agent(
            system=REQUIREMENT_EXTRACTION_SYSTEM,
            prompt=REQUIREMENT_EXTRACTION_PROMPT.format(story=story.raw_text),
        )
        items = _safe_json_list(raw)
        criteria = [
            AcceptanceCriterion(
                id=item.get("id", f"AC-{i+1}"),
                given=item.get("given", ""),
                when=item.get("when", ""),
                then=item.get("then", ""),
                category=item.get("category", "happy_path"),
            )
            for i, item in enumerate(items)
        ]
        return Requirements(story_title=story.title, criteria=criteria)

    def _mock_extract(self, story: Story) -> Requirements:
        criteria = [
            AcceptanceCriterion(
                id="AC-1",
                given="a registered customer with items in their cart",
                when="they submit a valid payment method at checkout",
                then="the order is confirmed and a receipt is displayed",
                category="happy_path",
            ),
            AcceptanceCriterion(
                id="AC-2",
                given="a customer applies a promo code at the edge of its expiry window",
                when="they proceed to checkout exactly at the expiry timestamp",
                then="the system consistently accepts or rejects the code without ambiguity",
                category="edge_case",
            ),
            AcceptanceCriterion(
                id="AC-3",
                given="a customer with an expired or invalid payment card",
                when="they attempt to complete checkout",
                then="checkout is blocked with a clear, actionable error message",
                category="negative",
            ),
        ]
        return Requirements(story_title=story.title, criteria=criteria)


def _safe_json_list(raw: str) -> list[dict]:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(json)?", "", raw).rstrip("`").strip()
    data = json.loads(raw)
    return data if isinstance(data, list) else data.get("criteria", [])
