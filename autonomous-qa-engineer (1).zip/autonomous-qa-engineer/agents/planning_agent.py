"""
PlanningAgent — bridges Deck steps 1 → 2 ("Understand Requirements" → "Generate Tests")

Turns acceptance criteria (+ an optional OpenAPI spec) into a scoped test plan:
which scenarios need functional (Playwright) coverage, which need load (Meter)
coverage, expected peak traffic, and priority.
"""
from __future__ import annotations

import json
import re

from config import SETTINGS, call_agent
from models import Requirements, TestPlan
from prompts.prompt_templates import PLANNING_PROMPT, PLANNING_SYSTEM


class PlanningAgent:
    def plan(self, requirements: Requirements, spec_text: str = "") -> TestPlan:
        if SETTINGS.mock_mode:
            return self._mock_plan(requirements, spec_text)

        criteria_text = "\n".join(
            f"- [{c.category}] GIVEN {c.given} WHEN {c.when} THEN {c.then}"
            for c in requirements.criteria
        )
        raw = call_agent(
            system=PLANNING_SYSTEM,
            prompt=PLANNING_PROMPT.format(criteria=criteria_text, spec=spec_text or "N/A"),
        )
        data = _safe_json(raw)
        return TestPlan(
            functional_scenarios=data.get("functional_scenarios", []),
            load_scenarios=data.get("load_scenarios", []),
            peak_traffic_rps=data.get("peak_traffic_rps", SETTINGS.peak_traffic_rps),
            priority=data.get("priority", "P1"),
            rationale=data.get("rationale", ""),
        )

    def _mock_plan(self, requirements: Requirements, spec_text: str) -> TestPlan:
        functional = [f"{c.id}: {c.then}" for c in requirements.criteria]
        load_scenarios = [
            "Checkout submission under sustained peak load",
            "Promo-code validation burst traffic at expiry boundary",
        ]
        return TestPlan(
            functional_scenarios=functional,
            load_scenarios=load_scenarios,
            peak_traffic_rps=SETTINGS.peak_traffic_rps,
            priority="P0" if any(c.category == "negative" for c in requirements.criteria) else "P1",
            rationale=(
                "Checkout is a revenue-critical path with a negative scenario in scope, "
                "so functional coverage is P0. Load scenarios target the same endpoints "
                "at the deck's reference peak of 500 req/s."
            ),
        )


def _safe_json(raw: str) -> dict:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(json)?", "", raw).rstrip("`").strip()
    return json.loads(raw)
