"""
ExecutionAgent — Deck step 3: "Orchestrate Execution"

Runs functional and load suites together and collects logs/traces/screenshots
for downstream triage. Ships with a deterministic simulated runner so the
pipeline is runnable without a real browser/CI grid; swap `run_suite()` for a
real `npx playwright test --reporter=json` / Meter subprocess call to go live.
"""
from __future__ import annotations

import random

from models import ExecutionResult, GeneratedTest, LoadWorkload


class ExecutionAgent:
    def __init__(self, seed: int | None = 2):
        self._rng = random.Random(seed)

    def run_suite(self, test: GeneratedTest, workload: LoadWorkload) -> ExecutionResult:
        """Simulate running the functional suite + load workload together in CI/CD.

        Replace this body with a real subprocess call, e.g.:
            subprocess.run(["npx", "playwright", "test", test.filename, "--reporter=json"])
        """
        test_names = _extract_test_names(test.content) or ["checkout_flow_default"]

        passed, failed, flaky, failures = 0, 0, 0, []
        for name in test_names:
            roll = self._rng.random()
            if roll < 0.7:
                passed += 1
            elif roll < 0.85:
                flaky += 1
                failures.append(self._failure_payload(name, kind="flaky"))
            else:
                failed += 1
                failures.append(self._failure_payload(name, kind="defect"))

        return ExecutionResult(
            suite=test.filename, passed=passed, failed=failed, flaky=flaky, failures=failures
        )

    def _failure_payload(self, test_name: str, kind: str) -> dict:
        if kind == "flaky":
            logs = (
                f"[{test_name}] Timeout 30000ms exceeded waiting for selector "
                "'#confirm-btn' (network idle after retry succeeded on 2nd attempt)"
            )
            trace = "network: 1 retried XHR to /api/checkout (200 on retry)"
        else:
            logs = (
                f"[{test_name}] Error: locator.click: Target closed / element not found: "
                "page.getByRole('button', { name: 'Proceed to Payment' })"
            )
            trace = "DOM snapshot shows button renamed to 'Continue to Payment' after UI refresh"
        return {
            "test_name": test_name,
            "logs": logs,
            "trace": trace,
            "screenshot": f"artifacts/{test_name}_failure.png",
        }


def _extract_test_names(ts_content: str) -> list[str]:
    import re

    return re.findall(r"test\(\s*'([^']+)'", ts_content)
