"""
LearningAgent — Deck step 6: "Learn Continuously"

Uses the deck's exact "Continuous Improvement" prompt to review run history,
identify recurring flaky tests and coverage gaps, and propose updated
test-generation prompts — closing the agentic feedback loop.
"""
from __future__ import annotations

import json

from config import SETTINGS, call_agent
from models import FailureAnalysis, LearningReport
from prompts.prompt_templates import CONTINUOUS_IMPROVEMENT_PROMPT

SYSTEM = """You are the LearningAgent in an autonomous QA pipeline. You review
run history across the week, spot recurring flaky tests and coverage gaps,
and propose concrete updates to the test-generation prompts."""


class LearningAgent:
    def learn(self, run_history: list[FailureAnalysis]) -> LearningReport:
        if SETTINGS.mock_mode:
            return self._mock_learn(run_history)

        history_text = "\n".join(
            f"- {a.test_name}: {a.classification} ({a.evidence[:120]})" for a in run_history
        )
        raw = call_agent(
            system=SYSTEM,
            prompt=CONTINUOUS_IMPROVEMENT_PROMPT.format(run_history=history_text or "No failures this run."),
            max_tokens=1200,
        )
        return LearningReport(
            recurring_flaky_tests=[a.test_name for a in run_history if a.classification == "flaky"],
            coverage_gaps=[],
            updated_prompt_suggestions=[raw],
        )

    def _mock_learn(self, run_history: list[FailureAnalysis]) -> LearningReport:
        flaky = [a.test_name for a in run_history if a.classification == "flaky"]
        defects = [a.test_name for a in run_history if a.classification == "defect"]
        suggestions = []
        if flaky:
            suggestions.append(
                "Add an explicit network-idle wait / retry-aware assertion pattern to the "
                "PlaywrightAgent generation prompt, since repeated transient XHR retries are "
                "the dominant flaky-failure signature this run."
            )
        if defects:
            suggestions.append(
                "Extend RequirementAgent extraction to flag UI copy/label fields as "
                "'locator-sensitive' so PlaywrightAgent prefers accessible-name patterns "
                "less coupled to exact button text (e.g. partial/regex matches where safe)."
            )
        if not suggestions:
            suggestions.append("No recurring issues detected this run; no prompt changes recommended.")
        return LearningReport(
            recurring_flaky_tests=flaky,
            coverage_gaps=["Concurrent promo-code redemption at exactly peak_traffic_rps"],
            updated_prompt_suggestions=suggestions,
        )
