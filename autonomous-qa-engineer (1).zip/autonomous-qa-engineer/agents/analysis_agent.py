"""
AnalysisAgent — Deck step 4: "Analyze Failures"

Uses the deck's exact "Failure Triage & Root Cause" prompt to classify each
failure as flaky, environment, or defect, citing evidence from logs/traces.
"""
from __future__ import annotations

from config import SETTINGS, call_agent
from models import ExecutionResult, FailureAnalysis
from prompts.prompt_templates import FAILURE_TRIAGE_PROMPT

SYSTEM = """You are the AnalysisAgent in an autonomous QA pipeline. You triage
test failures using logs, traces, and screenshots, and always cite the exact
evidence for your classification."""


class AnalysisAgent:
    def analyze(self, execution_result: ExecutionResult) -> list[FailureAnalysis]:
        analyses = []
        for failure in execution_result.failures:
            if SETTINGS.mock_mode:
                analyses.append(self._mock_analyze(failure))
            else:
                raw = call_agent(
                    system=SYSTEM,
                    prompt=FAILURE_TRIAGE_PROMPT.format(
                        test_name=failure["test_name"],
                        logs=failure["logs"],
                        trace=failure["trace"],
                    ),
                    max_tokens=800,
                )
                analyses.append(
                    FailureAnalysis(
                        test_name=failure["test_name"],
                        classification=_extract_classification(raw),
                        evidence=raw,
                        confidence=0.8,
                    )
                )
        return analyses

    def _mock_analyze(self, failure: dict) -> FailureAnalysis:
        is_flaky = "retried" in failure["logs"].lower() or "retry" in failure["trace"].lower()
        if is_flaky:
            return FailureAnalysis(
                test_name=failure["test_name"],
                classification="flaky",
                evidence=(
                    "Log shows the same request succeeded on retry with no code change; "
                    "trace confirms a transient network retry, not a stale locator or logic bug."
                ),
                confidence=0.86,
            )
        return FailureAnalysis(
            test_name=failure["test_name"],
            classification="defect",
            evidence=(
                "DOM snapshot in the trace shows the button label changed from "
                "'Proceed to Payment' to 'Continue to Payment' — the locator is stale, "
                "confirming a genuine defect in test-to-UI alignment rather than flake."
            ),
            confidence=0.91,
        )


def _extract_classification(raw: str) -> str:
    lowered = raw.lower()
    for label in ("flaky", "environment", "defect"):
        if label in lowered:
            return label
    return "defect"
