"""
MeterAgent — Deck step 2: "Generate Tests Autonomously" (load half)

Implements the deck's agentic, JMeter-style "Meter" engine. Uses the exact
"Load Scenario Generation" prompt from the deck to design a workload: ramp-up
profile, think-times, and pass/fail thresholds for P95 latency and error rate.
"""
from __future__ import annotations

import json
import re

from config import SETTINGS, call_agent
from models import LoadWorkload, TestPlan
from prompts.prompt_templates import LOAD_SCENARIO_PROMPT

SYSTEM = """You are the MeterAgent, an agentic JMeter-style performance test
designer. You always respond with strict JSON describing a load workload."""


class MeterAgent:
    def generate(self, test_plan: TestPlan, spec_text: str, filename: str = "workload.json") -> LoadWorkload:
        if SETTINGS.mock_mode:
            return LoadWorkload(filename=filename, content=self._mock_workload(test_plan))

        raw = call_agent(
            system=SYSTEM,
            prompt=LOAD_SCENARIO_PROMPT.format(peak_rps=test_plan.peak_traffic_rps, spec=spec_text or "N/A"),
            max_tokens=2000,
        )
        content = _safe_json(raw)
        return LoadWorkload(filename=filename, content=content)

    def _mock_workload(self, test_plan: TestPlan) -> dict:
        return {
            "scenarios": test_plan.load_scenarios,
            "ramp_up": {
                "stages": [
                    {"duration_s": 60, "target_rps": test_plan.peak_traffic_rps * 0.2},
                    {"duration_s": 120, "target_rps": test_plan.peak_traffic_rps * 0.6},
                    {"duration_s": 180, "target_rps": test_plan.peak_traffic_rps},
                ],
                "sustain_s": 300,
            },
            "think_time_ms": {"min": 200, "max": 1200},
            "thresholds": {
                "p95_latency_ms": SETTINGS.p95_latency_ms,
                "error_rate_max": SETTINGS.error_rate_threshold,
            },
            "peak_traffic_rps": test_plan.peak_traffic_rps,
        }


def _safe_json(raw: str) -> dict:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(json)?", "", raw).rstrip("`").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Model may have responded with prose + JSON; fall back to wrapping it.
        return {"raw_workload_design": raw}
