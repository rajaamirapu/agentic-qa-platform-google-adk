"""
FixAgent — Deck step 5: "Recommend Fixes"

Uses the deck's exact "Fix Recommendation" prompt to propose the minimal
Playwright locator/code fix and draft a pull-request diff. The `open_pull_request`
hook is where a real GitHub connector would push the diff automatically.
"""
from __future__ import annotations

from config import SETTINGS, call_agent
from models import FailureAnalysis, FixRecommendation
from prompts.prompt_templates import FIX_RECOMMENDATION_PROMPT

SYSTEM = """You are the FixAgent in an autonomous QA pipeline. You propose the
smallest possible code change that resolves a confirmed defect, and output a
unified diff ready to open as a pull request."""


class FixAgent:
    def recommend(self, analysis: FailureAnalysis, test_source: str = "") -> FixRecommendation | None:
        if analysis.classification != "defect":
            return None  # only genuine defects get a fix; flaky/env failures get flagged, not patched

        if SETTINGS.mock_mode:
            return self._mock_fix(analysis, test_source)

        content = call_agent(
            system=SYSTEM,
            prompt=FIX_RECOMMENDATION_PROMPT.format(
                test_name=analysis.test_name, evidence=analysis.evidence, test_source=test_source
            ),
            max_tokens=1000,
        )
        return FixRecommendation(test_name=analysis.test_name, summary="See diff.", diff=content)

    def _mock_fix(self, analysis: FailureAnalysis, test_source: str) -> FixRecommendation:
        diff = f"""--- a/tests/{analysis.test_name}.spec.ts
+++ b/tests/{analysis.test_name}.spec.ts
@@ -1,6 +1,6 @@
-  await page.getByRole('button', {{ name: 'Proceed to Payment' }}).click();
+  await page.getByRole('button', {{ name: 'Continue to Payment' }}).click();
"""
        return FixRecommendation(
            test_name=analysis.test_name,
            summary=(
                "Locator text drifted after a UI copy change ('Proceed to Payment' → "
                "'Continue to Payment'). Updated the role-based locator to match."
            ),
            diff=diff,
        )

    def open_pull_request(self, fix: FixRecommendation) -> str:
        """Hook for a real GitHub connector. Returns a mock PR URL in this project."""
        return f"https://github.com/example-org/example-repo/pull/NEW  (would contain: {fix.summary})"
