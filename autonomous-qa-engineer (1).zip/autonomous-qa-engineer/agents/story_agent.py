"""
StoryAgent — Deck step 1: "Understand Requirements"

Parses raw user stories, BRDs, or tickets into structured intent
(title, actors, narrative, explicit out-of-scope notes).
"""
from __future__ import annotations

import json
import re

from config import SETTINGS, call_agent
from models import Story
from prompts.prompt_templates import STORY_PARSE_PROMPT, STORY_PARSE_SYSTEM


class StoryAgent:
    def parse(self, story_text: str) -> Story:
        if SETTINGS.mock_mode:
            return self._mock_parse(story_text)

        raw = call_agent(
            system=STORY_PARSE_SYSTEM,
            prompt=STORY_PARSE_PROMPT.format(story_text=story_text),
        )
        data = _safe_json(raw)
        return Story(
            title=data.get("title", "Untitled Story"),
            actors=data.get("actors", []),
            narrative=data.get("narrative", story_text.strip()[:500]),
            raw_text=story_text,
            out_of_scope=data.get("out_of_scope", []),
        )

    # ---- deterministic fallback used when no API key is configured ----
    def _mock_parse(self, story_text: str) -> Story:
        title_match = re.search(r"^#\s*(.+)$", story_text, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else "Checkout Flow"
        actors = sorted(set(re.findall(r"As an? ([\w\s]+?),", story_text, re.IGNORECASE))) or [
            "Registered Customer"
        ]
        narrative_match = re.search(r"As an?.+?\.", story_text, re.DOTALL)
        narrative = (
            narrative_match.group(0).strip()
            if narrative_match
            else story_text.strip().splitlines()[0]
        )
        return Story(
            title=title,
            actors=[a.strip() for a in actors],
            narrative=narrative,
            raw_text=story_text,
            out_of_scope=["Payment gateway internals", "Third-party shipping carrier APIs"],
        )


def _safe_json(raw: str) -> dict:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(json)?", "", raw).rstrip("`").strip()
    return json.loads(raw)
