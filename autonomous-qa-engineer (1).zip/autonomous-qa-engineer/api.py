"""
FastAPI wrapper around the Autonomous QA Engineer pipeline.

Endpoints:
    POST /api/runs            -> upload a story (+ optional OpenAPI spec), run the
                                  full 8-agent pipeline synchronously, return all artifacts
    GET  /api/runs            -> list previous runs
    GET  /api/runs/{run_id}    -> re-fetch artifacts for a previous run
    GET  /api/runs/{run_id}/download/{artifact_path:path}
                                -> download a raw artifact file (spec.ts, .diff, .json)
    GET  /api/health           -> liveness check

Run with:
    uvicorn api:app --reload --port 8000
"""
from __future__ import annotations

import asyncio
import json
import shutil
import tempfile
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from config import SETTINGS
from orchestrator.workflow import run as run_pipeline

OUTPUT_ROOT = Path("output")

app = FastAPI(title="Autonomous QA Engineer API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok", "mode": "mock" if SETTINGS.mock_mode else "live", "model": SETTINGS.model}


@app.post("/api/runs")
async def create_run(
    story_text: str | None = Form(default=None),
    story_file: UploadFile | None = File(default=None),
    spec_file: UploadFile | None = File(default=None),
):
    if not story_text and not story_file:
        raise HTTPException(400, "Provide either story_text or a story_file upload.")

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        story_path = tmp_path / "story.md"
        if story_file is not None:
            story_path.write_bytes(await story_file.read())
        else:
            story_path.write_text(story_text)

        spec_path = None
        if spec_file is not None:
            spec_path = tmp_path / (spec_file.filename or "spec.yaml")
            spec_path.write_bytes(await spec_file.read())

        # run_pipeline() is synchronous (and may call the Anthropic API), so keep
        # the event loop free by running it in the default thread pool.
        loop = asyncio.get_event_loop()
        out_dir = await loop.run_in_executor(
            None,
            lambda: run_pipeline(
                story_path=str(story_path),
                spec_path=str(spec_path) if spec_path else None,
                output_root=str(OUTPUT_ROOT),
            ),
        )

    return _assemble_run(out_dir.name)


@app.get("/api/runs")
def list_runs():
    if not OUTPUT_ROOT.exists():
        return {"runs": []}
    runs = sorted((p.name for p in OUTPUT_ROOT.iterdir() if p.is_dir()), reverse=True)
    return {"runs": runs}


@app.get("/api/runs/{run_id}")
def get_run(run_id: str):
    return _assemble_run(run_id)


@app.get("/api/runs/{run_id}/download/{artifact_path:path}")
def download_artifact(run_id: str, artifact_path: str):
    file_path = (OUTPUT_ROOT / run_id / artifact_path).resolve()
    if OUTPUT_ROOT.resolve() not in file_path.parents or not file_path.exists():
        raise HTTPException(404, "Artifact not found")
    return FileResponse(file_path)


def _assemble_run(run_id: str) -> dict:
    run_dir = OUTPUT_ROOT / run_id
    if not run_dir.exists():
        raise HTTPException(404, f"Run '{run_id}' not found")

    def read_json(name: str):
        path = run_dir / name
        return json.loads(path.read_text()) if path.exists() else None

    def read_text(path: Path):
        return path.read_text() if path.exists() else None

    test_files = sorted((run_dir / "tests").glob("*.spec.ts")) if (run_dir / "tests").exists() else []
    meter_files = sorted((run_dir / "meter").glob("*.json")) if (run_dir / "meter").exists() else []
    fix_diff_path = run_dir / "06_fix_recommendation.diff"

    return {
        "run_id": run_id,
        "story": read_json("01_story.json"),
        "requirements": read_json("02_requirements.json"),
        "test_plan": read_json("03_test_plan.json"),
        "playwright_tests": [
            {"filename": f.name, "content": read_text(f)} for f in test_files
        ],
        "meter_workloads": [
            {"filename": f.name, "content": read_json(f"meter/{f.name}")} for f in meter_files
        ],
        "execution_report": read_json("04_execution_report.json"),
        "failure_analysis": read_json("05_failure_analysis.json"),
        "fix_recommendation_diff": read_text(fix_diff_path),
        "learning_report": read_json("07_learning_report.json"),
    }
