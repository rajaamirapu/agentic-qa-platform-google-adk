import { useRef, useState } from 'react'
import './UploadForm.css'

const SAMPLE_STORY = `# Checkout Flow

As a registered customer, I want to complete checkout with a saved payment
method so that I can confirm my order quickly and reliably, even during
high-traffic sale events.

- Promo codes have hard expiry timestamps.
- Expired/invalid card => checkout blocked with a clear error.`

export default function UploadForm({ onSubmit, disabled }) {
  const [storyText, setStoryText] = useState('')
  const [storyFile, setStoryFile] = useState(null)
  const [specFile, setSpecFile] = useState(null)
  const storyInputRef = useRef(null)
  const specInputRef = useRef(null)

  const canSubmit = !disabled && (storyText.trim().length > 0 || storyFile)

  function handleStoryFile(e) {
    const file = e.target.files?.[0]
    if (file) {
      setStoryFile(file)
      setStoryText('')
    }
  }

  function clearStoryFile() {
    setStoryFile(null)
    if (storyInputRef.current) storyInputRef.current.value = ''
  }

  function handleSpecFile(e) {
    setSpecFile(e.target.files?.[0] || null)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!canSubmit) return
    onSubmit({ storyText, storyFile, specFile })
  }

  return (
    <form className="upload-form" onSubmit={handleSubmit}>
      <div className="field">
        <div className="field-header">
          <label htmlFor="story-text">User story / BRD</label>
          <button
            type="button"
            className="link-btn"
            onClick={() => setStoryText(SAMPLE_STORY)}
            disabled={disabled}
          >
            Use sample
          </button>
        </div>

        {storyFile ? (
          <div className="file-chip">
            <span className="file-chip-name">{storyFile.name}</span>
            <button type="button" className="link-btn" onClick={clearStoryFile} disabled={disabled}>
              Remove
            </button>
          </div>
        ) : (
          <textarea
            id="story-text"
            placeholder="Paste a user story, BRD excerpt, or ticket description..."
            value={storyText}
            onChange={(e) => setStoryText(e.target.value)}
            rows={9}
            disabled={disabled}
          />
        )}

        <div className="field-footer">
          <label className="file-upload-label">
            <input
              ref={storyInputRef}
              type="file"
              accept=".md,.txt"
              onChange={handleStoryFile}
              disabled={disabled}
              hidden
            />
            <span className="link-btn">Upload .md / .txt instead</span>
          </label>
        </div>
      </div>

      <div className="field">
        <div className="field-header">
          <label htmlFor="spec-file">OpenAPI spec (optional)</label>
        </div>
        <label className="file-drop" htmlFor="spec-file">
          <input
            ref={specInputRef}
            id="spec-file"
            type="file"
            accept=".yaml,.yml,.json"
            onChange={handleSpecFile}
            disabled={disabled}
            hidden
          />
          {specFile ? (
            <span className="file-chip-name">{specFile.name}</span>
          ) : (
            <span className="file-drop-hint">Choose a .yaml / .json spec to size load tests</span>
          )}
        </label>
      </div>

      <button type="submit" className="run-btn" disabled={!canSubmit}>
        {disabled ? 'Running pipeline…' : 'Run pipeline'}
      </button>
    </form>
  )
}
