import { STAGES } from '../stages.js'
import './PipelineStepper.css'

/**
 * status: 'idle' | 'running' | 'done'
 * activeIndex: index of stage currently animating while running
 * result: assembled run result (used to color the final two stages by outcome)
 */
export default function PipelineStepper({ status, activeIndex, result }) {
  const execution = result?.execution_report
  const hasDefects = (result?.failure_analysis || []).some((f) => f.classification === 'defect')
  const hasFlaky = (result?.failure_analysis || []).some((f) => f.classification === 'flaky')

  return (
    <ol className="stepper" aria-label="Agent pipeline">
      {STAGES.map((stage, i) => {
        let state = 'idle'
        if (status === 'done') state = 'done'
        else if (status === 'running' && i < activeIndex) state = 'done'
        else if (status === 'running' && i === activeIndex) state = 'active'

        let tone = ''
        if (state === 'done' && stage.key === 'failure_analysis') {
          tone = hasDefects ? 'tone-defect' : hasFlaky ? 'tone-flaky' : 'tone-pass'
        } else if (state === 'done' && stage.key === 'execution_report' && execution) {
          tone = execution.failed > 0 ? 'tone-defect' : execution.flaky > 0 ? 'tone-flaky' : 'tone-pass'
        }

        return (
          <li key={stage.key} className={`step ${state} ${tone}`}>
            <span className="step-index">{i + 1}</span>
            <span className="step-body">
              <span className="step-agent">{stage.agent}</span>
              <span className="step-label">{stage.label}</span>
            </span>
            <span className="step-dot" aria-hidden="true" />
          </li>
        )
      })}
    </ol>
  )
}
