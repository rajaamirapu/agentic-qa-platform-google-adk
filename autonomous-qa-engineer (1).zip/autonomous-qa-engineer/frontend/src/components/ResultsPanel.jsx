import { useState } from 'react'
import { downloadUrl } from '../api.js'
import './ResultsPanel.css'

const TABS = [
  { key: 'story', label: 'Story' },
  { key: 'requirements', label: 'Requirements' },
  { key: 'plan', label: 'Test plan' },
  { key: 'playwright', label: 'Playwright' },
  { key: 'meter', label: 'Meter' },
  { key: 'execution', label: 'Execution' },
  { key: 'analysis', label: 'Analysis & fixes' },
  { key: 'learning', label: 'Learning' },
]

export default function ResultsPanel({ result }) {
  const [active, setActive] = useState('story')

  return (
    <div className="results-panel">
      <div className="tabs" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={active === t.key}
            className={`tab ${active === t.key ? 'active' : ''}`}
            onClick={() => setActive(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="tab-content">
        {active === 'story' && <StoryTab story={result.story} />}
        {active === 'requirements' && <RequirementsTab requirements={result.requirements} />}
        {active === 'plan' && <PlanTab plan={result.test_plan} />}
        {active === 'playwright' && (
          <FileListTab
            title="Generated Playwright suites"
            files={result.playwright_tests}
            runId={result.run_id}
            subdir="tests"
          />
        )}
        {active === 'meter' && (
          <FileListTab
            title="Generated Meter workloads"
            files={(result.meter_workloads || []).map((w) => ({
              filename: w.filename,
              content: JSON.stringify(w.content, null, 2),
            }))}
            runId={result.run_id}
            subdir="meter"
          />
        )}
        {active === 'execution' && <ExecutionTab report={result.execution_report} />}
        {active === 'analysis' && (
          <AnalysisTab analyses={result.failure_analysis} diff={result.fix_recommendation_diff} />
        )}
        {active === 'learning' && <LearningTab report={result.learning_report} />}
      </div>
    </div>
  )
}

function Empty({ label }) {
  return <p className="empty">{label}</p>
}

function StoryTab({ story }) {
  if (!story) return <Empty label="No story parsed yet." />
  return (
    <div className="card">
      <h3>{story.title}</h3>
      <p className="narrative">{story.narrative}</p>
      <div className="chip-row">
        {story.actors.map((a) => (
          <span key={a} className="chip">
            {a}
          </span>
        ))}
      </div>
      {story.out_of_scope?.length > 0 && (
        <>
          <h4>Out of scope</h4>
          <ul>
            {story.out_of_scope.map((o) => (
              <li key={o}>{o}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  )
}

const CATEGORY_TONE = {
  happy_path: 'tone-pass',
  edge_case: 'tone-flaky',
  negative: 'tone-defect',
}

function RequirementsTab({ requirements }) {
  if (!requirements) return <Empty label="No requirements extracted yet." />
  return (
    <div className="criteria-list">
      {requirements.criteria.map((c) => (
        <div key={c.id} className={`criterion ${CATEGORY_TONE[c.category] || ''}`}>
          <div className="criterion-head">
            <span className="criterion-id">{c.id}</span>
            <span className="criterion-category">{c.category.replace('_', ' ')}</span>
          </div>
          <p>
            <strong>Given</strong> {c.given}
          </p>
          <p>
            <strong>When</strong> {c.when}
          </p>
          <p>
            <strong>Then</strong> {c.then}
          </p>
        </div>
      ))}
    </div>
  )
}

function PlanTab({ plan }) {
  if (!plan) return <Empty label="No test plan yet." />
  return (
    <div className="card">
      <div className="stat-row">
        <div className="stat">
          <span className="stat-value">{plan.priority}</span>
          <span className="stat-label">Priority</span>
        </div>
        <div className="stat">
          <span className="stat-value">{plan.peak_traffic_rps}</span>
          <span className="stat-label">Peak req/s</span>
        </div>
      </div>
      <h4>Functional scenarios</h4>
      <ul>
        {plan.functional_scenarios.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ul>
      <h4>Load scenarios</h4>
      <ul>
        {plan.load_scenarios.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ul>
      <h4>Rationale</h4>
      <p className="narrative">{plan.rationale}</p>
    </div>
  )
}

function FileListTab({ title, files, runId, subdir }) {
  if (!files || files.length === 0) return <Empty label="Nothing generated yet." />
  return (
    <div>
      <h4>{title}</h4>
      {files.map((f) => (
        <div key={f.filename} className="code-block">
          <div className="code-block-head">
            <span>{f.filename}</span>
            <a href={downloadUrl(runId, `${subdir}/${f.filename}`)} download>
              Download
            </a>
          </div>
          <pre>
            <code>{f.content}</code>
          </pre>
        </div>
      ))}
    </div>
  )
}

function ExecutionTab({ report }) {
  if (!report) return <Empty label="No execution report yet." />
  return (
    <div className="card">
      <div className="stat-row">
        <div className="stat tone-pass">
          <span className="stat-value">{report.passed}</span>
          <span className="stat-label">Passed</span>
        </div>
        <div className="stat tone-flaky">
          <span className="stat-value">{report.flaky}</span>
          <span className="stat-label">Flaky</span>
        </div>
        <div className="stat tone-defect">
          <span className="stat-value">{report.failed}</span>
          <span className="stat-label">Failed</span>
        </div>
      </div>
      {report.failures?.length > 0 && (
        <>
          <h4>Failure evidence</h4>
          {report.failures.map((f) => (
            <div key={f.test_name} className="code-block">
              <div className="code-block-head">
                <span>{f.test_name}</span>
              </div>
              <pre>
                <code>
                  {f.logs}
                  {'\n'}
                  {f.trace}
                </code>
              </pre>
            </div>
          ))}
        </>
      )}
    </div>
  )
}

function AnalysisTab({ analyses, diff }) {
  if (!analyses || analyses.length === 0) {
    return <Empty label="No failures were triaged — everything passed cleanly." />
  }
  return (
    <div>
      {analyses.map((a) => (
        <div key={a.test_name} className={`card analysis-card tone-${a.classification}`}>
          <div className="criterion-head">
            <span className="criterion-id">{a.test_name}</span>
            <span className="criterion-category">
              {a.classification} · {Math.round(a.confidence * 100)}% confidence
            </span>
          </div>
          <p className="narrative">{a.evidence}</p>
        </div>
      ))}
      {diff && diff.trim() && !diff.startsWith('# No confirmed defects') && (
        <div className="code-block">
          <div className="code-block-head">
            <span>Recommended fix (unified diff)</span>
          </div>
          <pre>
            <code>{diff}</code>
          </pre>
        </div>
      )}
    </div>
  )
}

function LearningTab({ report }) {
  if (!report) return <Empty label="No learning report yet." />
  return (
    <div className="card">
      <h4>Recurring flaky tests</h4>
      {report.recurring_flaky_tests.length ? (
        <ul>
          {report.recurring_flaky_tests.map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ul>
      ) : (
        <p className="narrative">None detected this run.</p>
      )}
      <h4>Coverage gaps</h4>
      <ul>
        {report.coverage_gaps.map((g) => (
          <li key={g}>{g}</li>
        ))}
      </ul>
      <h4>Suggested prompt updates</h4>
      <ul>
        {report.updated_prompt_suggestions.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ul>
    </div>
  )
}
