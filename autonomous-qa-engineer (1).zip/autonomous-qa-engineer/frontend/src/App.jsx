import { useEffect, useRef, useState } from 'react'
import UploadForm from './components/UploadForm.jsx'
import PipelineStepper from './components/PipelineStepper.jsx'
import ResultsPanel from './components/ResultsPanel.jsx'
import { checkHealth, createRun } from './api.js'
import { STAGES } from './stages.js'
import './App.css'

export default function App() {
  const [health, setHealth] = useState(null)
  const [status, setStatus] = useState('idle') // idle | running | done | error
  const [activeIndex, setActiveIndex] = useState(0)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const timerRef = useRef(null)

  useEffect(() => {
    checkHealth()
      .then(setHealth)
      .catch(() => setHealth(null))
  }, [])

  useEffect(() => () => clearInterval(timerRef.current), [])

  async function handleSubmit({ storyText, storyFile, specFile }) {
    setStatus('running')
    setError(null)
    setResult(null)
    setActiveIndex(0)

    // The backend runs the full pipeline in one request; animate the stepper
    // through its stages while we wait so the 8-agent flow stays visible.
    let step = 0
    timerRef.current = setInterval(() => {
      step = Math.min(step + 1, STAGES.length - 1)
      setActiveIndex(step)
    }, 900)

    try {
      const data = await createRun({ storyText, storyFile, specFile })
      clearInterval(timerRef.current)
      setResult(data)
      setStatus('done')
    } catch (err) {
      clearInterval(timerRef.current)
      setError(err.message)
      setStatus('error')
    }
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <h1>Autonomous QA Engineer</h1>
          <p className="tagline">Agentic AI + Playwright — from user story to shipped fix</p>
        </div>
        <div className={`mode-badge ${health?.mode === 'live' ? 'mode-live' : 'mode-mock'}`}>
          {health ? (health.mode === 'live' ? `live · ${health.model}` : 'mock mode') : 'backend offline'}
        </div>
      </header>

      <main className="app-body">
        <aside className="sidebar">
          <section className="panel">
            <h2>New run</h2>
            <UploadForm onSubmit={handleSubmit} disabled={status === 'running'} />
          </section>

          <section className="panel">
            <h2>Pipeline</h2>
            <PipelineStepper status={status === 'error' ? 'idle' : status} activeIndex={activeIndex} result={result} />
          </section>
        </aside>

        <section className="panel results">
          <h2>Results</h2>
          {status === 'idle' && (
            <p className="empty-state">
              Paste or upload a user story on the left, then run the pipeline to see requirements,
              generated Playwright &amp; Meter tests, execution results, failure triage, fixes, and
              the learning report — all in one place.
            </p>
          )}
          {status === 'running' && !result && <p className="empty-state">Running the 8-agent pipeline…</p>}
          {status === 'error' && <p className="error-state">{error}</p>}
          {result && <ResultsPanel result={result} />}
        </section>
      </main>
    </div>
  )
}
