export const STAGES = [
  { key: 'story', agent: 'StoryAgent', label: 'Understand the story' },
  { key: 'requirements', agent: 'RequirementAgent', label: 'Extract acceptance criteria' },
  { key: 'test_plan', agent: 'PlanningAgent', label: 'Scope the test plan' },
  { key: 'playwright_tests', agent: 'PlaywrightAgent', label: 'Generate functional tests' },
  { key: 'meter_workloads', agent: 'MeterAgent', label: 'Design the load workload' },
  { key: 'execution_report', agent: 'ExecutionAgent', label: 'Execute functional + load suites' },
  { key: 'failure_analysis', agent: 'AnalysisAgent', label: 'Triage failures' },
  { key: 'learning_report', agent: 'LearningAgent', label: 'Learn for next run' },
]
