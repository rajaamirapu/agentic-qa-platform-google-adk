const BASE = '/api'

export async function checkHealth() {
  const res = await fetch(`${BASE}/health`)
  if (!res.ok) throw new Error('Backend unreachable')
  return res.json()
}

export async function listRuns() {
  const res = await fetch(`${BASE}/runs`)
  if (!res.ok) throw new Error('Failed to list runs')
  return res.json()
}

export async function getRun(runId) {
  const res = await fetch(`${BASE}/runs/${encodeURIComponent(runId)}`)
  if (!res.ok) throw new Error(`Run ${runId} not found`)
  return res.json()
}

export async function createRun({ storyText, storyFile, specFile }) {
  const form = new FormData()
  if (storyFile) {
    form.append('story_file', storyFile)
  } else {
    form.append('story_text', storyText || '')
  }
  if (specFile) form.append('spec_file', specFile)

  const res = await fetch(`${BASE}/runs`, { method: 'POST', body: form })
  if (!res.ok) {
    const detail = await res.json().catch(() => ({}))
    throw new Error(detail.detail || 'Pipeline run failed')
  }
  return res.json()
}

export function downloadUrl(runId, artifactPath) {
  return `${BASE}/runs/${encodeURIComponent(runId)}/download/${artifactPath}`
}
