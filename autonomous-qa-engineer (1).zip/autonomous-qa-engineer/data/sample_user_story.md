# Checkout Flow

As a registered customer, I want to complete checkout with a saved payment
method so that I can confirm my order quickly and reliably, even during
high-traffic sale events.

## Notes
- Promo codes may be applied before payment and have hard expiry timestamps.
- Payment methods include saved cards and UPI (India) only for this release.
- Out of scope: payment gateway internals, third-party shipping carrier APIs.

## Acceptance Criteria (draft, from product)
- Valid saved card + valid cart => order confirmed, receipt shown.
- Promo code applied exactly at expiry boundary => must not silently succeed
  for one customer and fail for another under load.
- Expired/invalid card => checkout blocked with a clear error, no partial order created.
