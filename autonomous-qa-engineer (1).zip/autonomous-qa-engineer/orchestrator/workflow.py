"""
Orchestrator for the Autonomous QA Engineer pipeline:

    Story -> Requirement -> Planning -> (Playwright + Meter) -> Execution
          -> Analysis -> Fix -> Learning

Mirrors the deck's core capability stack: Understand Requirements ->
Generate Tests -> Execute Workloads -> Analyze Failures -> Recommend Fixes
-> Continuously Improve.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from agents.analysis_agent import AnalysisAgent
from agents.execution_agent import ExecutionAgent
from agents.fix_agent import FixAgent
from agents.learning_agent import LearningAgent
from agents.meter_agent import MeterAgent
from agents.planning_agent import PlanningAgent
from agents.playwright_agent import PlaywrightAgent
from agents.requirement_agent import RequirementAgent
from agents.story_agent import StoryAgent
from config import SETTINGS


def run(story_path: str = "data/sample_user_story.md", spec_path: str | None = "data/sample_openapi.yaml",
        output_root: str = "output") -> Path:
    story_text = Path(story_path).read_text()
    spec_text = Path(spec_path).read_text() if spec_path and Path(spec_path).exists() else ""

    run_id = datetime.now().strftime("%Y-%m-%dT%H%M%S")
    out_dir = Path(output_root) / run_id
    (out_dir / "tests").mkdir(parents=True, exist_ok=True)
    (out_dir / "meter").mkdir(parents=True, exist_ok=True)

    mode = "MOCK" if SETTINGS.mock_mode else f"LIVE ({SETTINGS.model})"
    print(f"=== Autonomous QA Engineer — run {run_id} [{mode}] ===\n")

    # 1. Understand Requirements
    print("[1/8] StoryAgent: parsing story ...")
    story = StoryAgent().parse(story_text)
    _write_json(out_dir / "01_story.json", story.to_dict())

    print("[2/8] RequirementAgent: extracting acceptance criteria ...")
    requirements = RequirementAgent().extract(story)
    _write_json(out_dir / "02_requirements.json", requirements.to_dict())

    # 2. Generate Tests
    print("[3/8] PlanningAgent: building test plan ...")
    test_plan = PlanningAgent().plan(requirements, spec_text)
    _write_json(out_dir / "03_test_plan.json", test_plan.to_dict())

    print("[4/8] PlaywrightAgent + MeterAgent: generating functional & load tests ...")
    functional_test = PlaywrightAgent().generate(story, requirements)
    (out_dir / "tests" / functional_test.filename).write_text(functional_test.content)

    load_workload = MeterAgent().generate(test_plan, spec_text)
    _write_json(out_dir / "meter" / load_workload.filename, load_workload.content)

    # 3. Orchestrate Execution
    print("[5/8] ExecutionAgent: running functional + load suites ...")
    execution_result = ExecutionAgent().run_suite(functional_test, load_workload)
    _write_json(out_dir / "04_execution_report.json", execution_result.to_dict())
    print(
        f"       -> passed={execution_result.passed} failed={execution_result.failed} "
        f"flaky={execution_result.flaky}"
    )

    # 4. Analyze Failures
    print("[6/8] AnalysisAgent: triaging failures ...")
    analyses = AnalysisAgent().analyze(execution_result)
    _write_json(out_dir / "05_failure_analysis.json", [a.to_dict() for a in analyses])

    # 5. Recommend Fixes
    print("[7/8] FixAgent: recommending fixes for confirmed defects ...")
    fixes = [FixAgent().recommend(a, functional_test.content) for a in analyses]
    fixes = [f for f in fixes if f is not None]
    if fixes:
        diff_text = "\n".join(f.diff for f in fixes)
        (out_dir / "06_fix_recommendation.diff").write_text(diff_text)
        for f in fixes:
            print(f"       -> {FixAgent().open_pull_request(f)}")
    else:
        (out_dir / "06_fix_recommendation.diff").write_text("# No confirmed defects this run.\n")

    # 6. Learn Continuously
    print("[8/8] LearningAgent: reviewing run history ...")
    learning_report = LearningAgent().learn(analyses)
    _write_json(out_dir / "07_learning_report.json", learning_report.to_dict())

    print(f"\nAll artifacts written to: {out_dir}/")
    return out_dir


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))
