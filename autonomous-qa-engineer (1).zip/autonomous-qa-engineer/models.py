"""Shared data structures passed between agents in the pipeline."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Story:
    title: str
    actors: list[str]
    narrative: str
    raw_text: str
    out_of_scope: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class AcceptanceCriterion:
    id: str
    given: str
    when: str
    then: str
    category: str  # "happy_path" | "edge_case" | "negative"

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class Requirements:
    story_title: str
    criteria: list[AcceptanceCriterion]

    def to_dict(self) -> dict[str, Any]:
        return {
            "story_title": self.story_title,
            "criteria": [c.to_dict() for c in self.criteria],
        }


@dataclass
class TestPlan:
    functional_scenarios: list[str]
    load_scenarios: list[str]
    peak_traffic_rps: int
    priority: str  # "P0" | "P1" | "P2"
    rationale: str

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class GeneratedTest:
    filename: str
    language: str
    content: str

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class LoadWorkload:
    filename: str
    content: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {"filename": self.filename, "content": self.content}


@dataclass
class ExecutionResult:
    suite: str
    passed: int
    failed: int
    flaky: int
    failures: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class FailureAnalysis:
    test_name: str
    classification: str  # "flaky" | "environment" | "defect"
    evidence: str
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class FixRecommendation:
    test_name: str
    summary: str
    diff: str

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class LearningReport:
    recurring_flaky_tests: list[str]
    coverage_gaps: list[str]
    updated_prompt_suggestions: list[str]

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__
