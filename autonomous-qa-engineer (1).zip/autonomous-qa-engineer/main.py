"""
CLI entrypoint for the Autonomous QA Engineer pipeline.

Usage:
    python main.py --story data/sample_user_story.md --spec data/sample_openapi.yaml
    python main.py --mock        # force deterministic mock mode regardless of .env
"""
from __future__ import annotations

import argparse
import os

def main():
    parser = argparse.ArgumentParser(description="Autonomous QA Engineer — Agentic AI + Playwright")
    parser.add_argument("--story", default="data/sample_user_story.md", help="Path to user story / BRD")
    parser.add_argument("--spec", default="data/sample_openapi.yaml", help="Path to OpenAPI spec (optional)")
    parser.add_argument("--output", default="output", help="Output root directory")
    parser.add_argument("--mock", action="store_true", help="Force mock mode even if ANTHROPIC_API_KEY is set")
    args = parser.parse_args()

    if args.mock:
        os.environ.pop("ANTHROPIC_API_KEY", None)

    # Imported after potential env mutation above so config.py picks up mock mode correctly.
    from orchestrator.workflow import run

    run(story_path=args.story, spec_path=args.spec, output_root=args.output)


if __name__ == "__main__":
    main()
