"""
Prompt templates used by the agents.

The five core templates below are taken verbatim from the deck's
"Agentic Prompt Patterns" slide. StoryAgent and PlanningAgent add two
supporting prompts (story parsing, test planning) needed to wire the
pipeline together end to end.
"""

STORY_PARSE_SYSTEM = """You are the StoryAgent in an autonomous QA pipeline.
You read raw user stories, BRDs, or tickets and extract structured intent.
Always respond with strict JSON matching the requested schema and nothing else."""

STORY_PARSE_PROMPT = """Parse the following user story / BRD into structured JSON with this schema:
{{
  "title": string,
  "actors": [string],
  "narrative": string,
  "out_of_scope": [string]
}}

Story:
---
{story_text}
---
Respond with JSON only."""


REQUIREMENT_EXTRACTION_SYSTEM = """You are the RequirementAgent in an autonomous QA pipeline.
You read a parsed user story and extract testable scenarios and acceptance criteria."""

# Verbatim from deck slide 5: "Requirement → Test Generation"
REQUIREMENT_TO_TEST_PROMPT = """Read this user story and acceptance criteria. Generate a Playwright test suite (TypeScript) covering happy path, edge cases, and negative scenarios. Use resilient role-based locators.

User story:
{story}

Acceptance criteria:
{criteria}
"""

REQUIREMENT_EXTRACTION_PROMPT = """Read the following user story and extract acceptance criteria as testable
Given/When/Then scenarios. Cover happy path, edge cases, and negative scenarios.
Respond with strict JSON: a list of objects with fields
id, given, when, then, category ("happy_path" | "edge_case" | "negative").

Story:
{story}
"""


PLANNING_SYSTEM = """You are the PlanningAgent in an autonomous QA pipeline.
You turn acceptance criteria into a scoped test plan covering both functional
(Playwright) and load (Meter) coverage, and set priority."""

PLANNING_PROMPT = """Given these acceptance criteria and the API spec below, produce a test plan as JSON:
{{
  "functional_scenarios": [string],
  "load_scenarios": [string],
  "peak_traffic_rps": int,
  "priority": "P0" | "P1" | "P2",
  "rationale": string
}}

Acceptance criteria:
{criteria}

API spec (may be empty):
{spec}
"""


# Verbatim from deck slide 5: "Load Scenario Generation"
LOAD_SCENARIO_PROMPT = """Given this OpenAPI spec and expected peak traffic of {peak_rps} req/s, design a Meter workload: ramp-up profile, think-times, and pass/fail thresholds for P95 latency and error rate.

OpenAPI spec:
{spec}
"""


# Verbatim from deck slide 5: "Failure Triage & Root Cause"
FAILURE_TRIAGE_PROMPT = """Here are the failing test logs, screenshot, and trace. Classify this failure as flaky, environment, or defect, and cite the exact evidence for your classification.

Test: {test_name}
Logs:
{logs}

Trace:
{trace}
"""


# Verbatim from deck slide 5: "Fix Recommendation"
FIX_RECOMMENDATION_PROMPT = """The failure is a stale locator, confirmed by the DOM snapshot. Propose the minimal Playwright locator fix and generate a pull request diff.

Test: {test_name}
Failure evidence:
{evidence}

Current test source:
{test_source}
"""


# Verbatim from deck slide 5: "Continuous Improvement"
CONTINUOUS_IMPROVEMENT_PROMPT = """Review this week's run history. Identify recurring flaky tests and coverage gaps versus new commits, then propose updated test-generation prompts.

Run history:
{run_history}
"""
