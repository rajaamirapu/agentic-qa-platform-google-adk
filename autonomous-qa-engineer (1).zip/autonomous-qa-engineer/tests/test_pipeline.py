"""Smoke test: the full pipeline runs end-to-end in mock mode and produces
every expected artifact."""
import os
import sys
from pathlib import Path

os.environ.pop("ANTHROPIC_API_KEY", None)  # force mock mode for this test

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from orchestrator.workflow import run  # noqa: E402


def test_pipeline_end_to_end(tmp_path):
    out_dir = run(
        story_path="data/sample_user_story.md",
        spec_path="data/sample_openapi.yaml",
        output_root=str(tmp_path),
    )

    expected = [
        "01_story.json",
        "02_requirements.json",
        "03_test_plan.json",
        "04_execution_report.json",
        "05_failure_analysis.json",
        "06_fix_recommendation.diff",
        "07_learning_report.json",
    ]
    for filename in expected:
        assert (out_dir / filename).exists(), f"missing {filename}"

    ts_files = list((out_dir / "tests").glob("*.spec.ts"))
    assert ts_files, "no Playwright spec generated"

    workload_files = list((out_dir / "meter").glob("*.json"))
    assert workload_files, "no Meter workload generated"
