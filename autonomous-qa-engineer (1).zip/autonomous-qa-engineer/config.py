"""
Central configuration for the Autonomous QA Engineer pipeline.

Loads settings from environment variables (via .env if present) and exposes
a single `get_client()` factory so every agent shares the same Anthropic
client and model configuration.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    anthropic_api_key: str | None = os.getenv("ANTHROPIC_API_KEY") or None
    model: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")
    peak_traffic_rps: int = int(os.getenv("PEAK_TRAFFIC_RPS", "500"))
    p95_latency_ms: int = int(os.getenv("P95_LATENCY_MS", "800"))
    error_rate_threshold: float = float(os.getenv("ERROR_RATE_THRESHOLD", "0.01"))

    @property
    def mock_mode(self) -> bool:
        return not self.anthropic_api_key


SETTINGS = Settings()

_client = None


def get_client():
    """Lazily construct a shared Anthropic client. Returns None in mock mode."""
    global _client
    if SETTINGS.mock_mode:
        return None
    if _client is None:
        import anthropic

        _client = anthropic.Anthropic(api_key=SETTINGS.anthropic_api_key)
    return _client


def call_agent(system: str, prompt: str, max_tokens: int = 2000) -> str:
    """
    Shared helper every agent uses to talk to Claude.
    Falls back to raising in mock mode — callers should check
    `SETTINGS.mock_mode` first and use their own deterministic mock output.
    """
    client = get_client()
    if client is None:
        raise RuntimeError("call_agent() invoked while in mock mode")

    response = client.messages.create(
        model=SETTINGS.model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")
