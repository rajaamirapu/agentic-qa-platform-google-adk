# Autonomous QA Engineer
### Agentic AI + Playwright — Autonomous Quality Engineering for Enterprise Test Automation

This project is the working implementation behind the "Agentic AI + Playwright" platform deck.
It is an AI-driven pipeline of 8 cooperating agents that reads a requirement, autonomously
generates functional (Playwright) and load ("Meter") tests, executes them, triages failures,
recommends fixes, and learns from every run — with minimal human intervention.

```
Story → Requirement → Planning → (Playwright + Meter) → Execution → Analysis → Fix → Learning
```

This mirrors the platform's core capability stack:
**Understand Requirements → Generate Tests → Execute Workloads → Analyze Failures →
Recommend Fixes → Continuously Improve.**

---

## 1. Architecture

```
                         ┌─────────────────────────────────────────────────────────┐
                         │                     ORCHESTRATOR                         │
                         │                (orchestrator/workflow.py)                │
                         └─────────────────────────────────────────────────────────┘
                                                    │
   ┌──────────────┐   ┌──────────────────┐   ┌──────────────┐
   │  StoryAgent  │──▶│ RequirementAgent │──▶│ PlanningAgent│
   │ parse story  │   │ acceptance crit. │   │  test plan   │
   └──────────────┘   └──────────────────┘   └──────┬───────┘
                                                      │
                              ┌───────────────────────┴────────────────────────┐
                              ▼                                                ▼
                    ┌──────────────────┐                              ┌───────────────┐
                    │  PlaywrightAgent │                              │   MeterAgent  │
                    │  functional (.ts)│                              │ load workload │
                    └────────┬─────────┘                              └───────┬───────┘
                              └───────────────────────┬────────────────────────┘
                                                        ▼
                                              ┌──────────────────┐
                                              │  ExecutionAgent  │
                                              │ run + collect logs│
                                              └────────┬─────────┘
                                                        ▼
                                              ┌──────────────────┐
                                              │  AnalysisAgent   │
                                              │ flaky/env/defect │
                                              └────────┬─────────┘
                                                        ▼
                                              ┌──────────────────┐
                                              │    FixAgent      │
                                              │ locator fix / PR │
                                              └────────┬─────────┘
                                                        ▼
                                              ┌──────────────────┐
                                              │  LearningAgent   │
                                              │ prompts / coverage│
                                              └──────────────────┘
```

## 2. Agents

| Agent | File | Deck Step | Responsibility |
|---|---|---|---|
| `StoryAgent` | `agents/story_agent.py` | 1. Understand Requirements | Parses raw user stories / BRDs into structured intent (actors, narrative, in/out of scope). |
| `RequirementAgent` | `agents/requirement_agent.py` | 1. Understand Requirements | Extracts testable scenarios + Given/When/Then acceptance criteria, tags happy-path/edge/negative. |
| `PlanningAgent` | `agents/planning_agent.py` | 2. Generate Tests (planning) | Builds a test plan: maps criteria → functional vs. load coverage, estimates peak traffic and priority. |
| `PlaywrightAgent` | `agents/playwright_agent.py` | 2. Generate Tests | Generates a Playwright TypeScript suite with resilient role-based locators. |
| `MeterAgent` | `agents/meter_agent.py` | 2. Generate Tests | Generates the agentic "Meter" load workload (ramp-up, think-times, P95/error thresholds) from an OpenAPI spec. |
| `ExecutionAgent` | `agents/execution_agent.py` | 3. Orchestrate Execution | Runs (or simulates) functional + load suites together, collects logs/traces/screenshots. |
| `AnalysisAgent` | `agents/analysis_agent.py` | 4. Analyze Failures | Classifies each failure as **flaky / environment / defect**, citing evidence. |
| `FixAgent` | `agents/fix_agent.py` | 5. Recommend Fixes | Proposes the minimal code/locator/data fix and drafts a PR diff. |
| `LearningAgent` | `agents/learning_agent.py` | 6. Learn Continuously | Reviews run history, finds recurring flaky tests / coverage gaps, proposes updated prompts. |

Every agent prompt is lifted directly from the deck's **"Agentic Prompt Patterns"** slide —
see `prompts/prompt_templates.py`.

## 3. Running it

### CLI

```bash
pip install -r requirements.txt
cp .env.example .env          # add ANTHROPIC_API_KEY (optional — see Mock Mode below)
python main.py --story data/sample_user_story.md --spec data/sample_openapi.yaml
```

### Web app (FastAPI + React)

A small full-stack app lets you upload/paste a user story in the browser and watch
the 8-agent pipeline run, with results (requirements, generated Playwright/Meter
tests, execution report, failure triage, fixes, learning report) rendered live.

**Backend** (FastAPI, serves the pipeline over HTTP):

```bash
pip install -r requirements.txt
uvicorn api:app --reload --port 8000
```

**Frontend** (React + Vite, in a separate terminal):

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173, proxies /api to :8000
```

Open `http://localhost:5173`, paste a story (or click "Use sample"), optionally
attach an OpenAPI spec, and click **Run pipeline**. The left rail shows the
8-agent pipeline lighting up stage by stage; the right panel shows every
artifact in tabs, each downloadable individually.

Backend API surface:

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/runs` | Upload a story (+ optional spec), run the pipeline, return all artifacts |
| `GET` | `/api/runs` | List previous run IDs |
| `GET` | `/api/runs/{run_id}` | Re-fetch artifacts for a previous run |
| `GET` | `/api/runs/{run_id}/download/{artifact_path}` | Download a raw artifact file |
| `GET` | `/api/health` | Liveness + mock/live mode check |

Outputs land in `output/<run_id>/`:

```
output/2026-07-08T120000/
├── 01_story.json
├── 02_requirements.json
├── 03_test_plan.json
├── tests/checkout.spec.ts        # PlaywrightAgent
├── meter/checkout_workload.json  # MeterAgent
├── 04_execution_report.json
├── 05_failure_analysis.json
├── 06_fix_recommendation.diff
└── 07_learning_report.json
```

### Mock Mode (no API key needed)

If `ANTHROPIC_API_KEY` is not set, every agent falls back to a deterministic mock
implementation (`--mock` flag also forces this). This lets you run the full
pipeline end-to-end to see the shape of every artifact before wiring in real credentials.

## 4. Configuration

All configuration lives in `config.py` / `.env`:

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | — | Anthropic API key. Unset → mock mode. |
| `ANTHROPIC_MODEL` | `claude-sonnet-5` | Model used by every agent. |
| `PEAK_TRAFFIC_RPS` | `500` | Default peak traffic assumption for load-test generation (matches deck example). |
| `P95_LATENCY_MS` | `800` | Default P95 latency threshold. |
| `ERROR_RATE_THRESHOLD` | `0.01` | Default acceptable error rate (1%). |

## 5. Extending

- Swap `ExecutionAgent`'s simulated runner for a real `npx playwright test` / Meter (JMeter-style)
  subprocess call — the hook is `ExecutionAgent.run_suite()`.
- Add a GitHub connector in `FixAgent.open_pull_request()` to actually push the generated diff.
- `LearningAgent` writes updated prompt templates to `output/<run_id>/07_learning_report.json`;
  wire this into `prompts/prompt_templates.py` to close the feedback loop automatically.

## 6. Project Layout

```
autonomous-qa-engineer/
├── main.py                    # CLI entrypoint
├── config.py                  # env / settings
├── models.py                  # shared dataclasses
├── orchestrator/
│   └── workflow.py            # pipeline orchestration
├── agents/
│   ├── story_agent.py
│   ├── requirement_agent.py
│   ├── planning_agent.py
│   ├── playwright_agent.py
│   ├── meter_agent.py
│   ├── execution_agent.py
│   ├── analysis_agent.py
│   ├── fix_agent.py
│   └── learning_agent.py
├── prompts/
│   └── prompt_templates.py    # exact prompts from the deck
├── data/
│   ├── sample_user_story.md
│   └── sample_openapi.yaml
├── tests/
│   └── test_pipeline.py       # end-to-end smoke test (mock mode)
├── frontend/                  # React + Vite upload UI
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       └── components/
│           ├── UploadForm.jsx
│           ├── PipelineStepper.jsx
│           └── ResultsPanel.jsx
└── output/                    # generated per run
```
